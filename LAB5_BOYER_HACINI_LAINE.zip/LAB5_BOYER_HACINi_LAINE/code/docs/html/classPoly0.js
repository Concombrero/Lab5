var classPoly0 =
[
    [ "Poly0", "classPoly0.html#a82a188766db841a3303be6de9cebcdcc", null ],
    [ "derivative", "classPoly0.html#a2c6233fa89b447535a20e07301282520", null ],
    [ "display", "classPoly0.html#a1f332888aeadad3ff8e9fc9fd84dea80", null ],
    [ "eval", "classPoly0.html#a99e5280255a4fefcb0c4d16d8be50ecb", null ],
    [ "k0", "classPoly0.html#ae74022b4f0c2c2e8815df872df3e161b", null ]
];