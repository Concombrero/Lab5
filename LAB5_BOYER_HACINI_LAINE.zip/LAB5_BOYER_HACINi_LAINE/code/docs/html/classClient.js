var classClient =
[
    [ "Client", "classClient.html#a441b0df2f966d7ef212dbd7ad97f70d7", null ],
    [ "Client", "classClient.html#ab74cbe8124ada5342d56030bd608876b", null ],
    [ "~Client", "classClient.html#a840e519ca781888cbd54181572ebe3a7", null ],
    [ "createAccount", "classClient.html#ae06d3f82a48f3c23fee66c150284ea15", null ],
    [ "credit", "classClient.html#a2cba21dbf2d7223d9233f9a117e640a5", null ],
    [ "debit", "classClient.html#aea373e2b310700a294e040a8c52681d1", null ],
    [ "get_id", "classClient.html#ae600cde4b0e7c02be20b76fda7f0b7d2", null ],
    [ "operator<<", "classClient.html#a84126cd2791173dac14dbac668bd8eee", null ],
    [ "accounts", "classClient.html#a811ed3995e3c0a223f64f3945e6b8ad9", null ],
    [ "identifier", "classClient.html#a63200b2a615353b0afcec162dddbc4b9", null ],
    [ "maxAccounts", "classClient.html#a59905eacef3c93514803343a1446db73", null ],
    [ "name", "classClient.html#a456e36f9972a8bf3ecdb5f0e70b3bd5d", null ],
    [ "nb_currentAccounts", "classClient.html#acfa1a3e58d0c5599de8c961b5827a9e6", null ]
];