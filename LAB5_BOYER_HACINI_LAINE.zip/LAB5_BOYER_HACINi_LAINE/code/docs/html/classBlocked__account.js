var classBlocked__account =
[
    [ "Blocked_account", "classBlocked__account.html#ad7ccacf080e8046941d8e9c0ea3bdb48", null ],
    [ "debit", "classBlocked__account.html#a59a054acccb82c9536b4a0c988ee72e7", null ]
];