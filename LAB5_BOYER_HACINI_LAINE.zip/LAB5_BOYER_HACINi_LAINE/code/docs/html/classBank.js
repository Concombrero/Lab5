var classBank =
[
    [ "Bank", "classBank.html#a95972e189e85e1a572348811a8bf0d57", null ],
    [ "insertClient", "classBank.html#a1fd6ab6aba6e9b5378aec019bcb79738", null ],
    [ "operator<<", "classBank.html#aa4f22d51b6c552b2a8b69497c8d3b39d", null ],
    [ "clients_collection", "classBank.html#ac6bcfb2d1d3eeb811d885d6e21c478c3", null ]
];