var classPoly2 =
[
    [ "Poly2", "classPoly2.html#a98b8c3603212c40abc5c9ac2624fa08d", null ],
    [ "derivative", "classPoly2.html#aa1c1a2a7ce7f83ae447bbbf0e069b13e", null ],
    [ "display", "classPoly2.html#a9282a1c2bb35d6583965362dd473aef1", null ],
    [ "eval", "classPoly2.html#afaf70d28e167849d23f956eabf1b0900", null ],
    [ "k0", "classPoly2.html#ac9d04ca8ed0a09eaa9b3dedc20a25e68", null ],
    [ "k1", "classPoly2.html#adf032de1b0e8fc5dccf73a94f3be49bf", null ],
    [ "k2", "classPoly2.html#a8f03f5a810d3f53f966eee262d2ff09a", null ]
];