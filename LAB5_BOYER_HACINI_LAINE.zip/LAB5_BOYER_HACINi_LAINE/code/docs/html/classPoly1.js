var classPoly1 =
[
    [ "Poly1", "classPoly1.html#a6e92383dc040d48079c627251fbe0df2", null ],
    [ "derivative", "classPoly1.html#ab81d64c94cb7da5ef5473da0e2aacbe8", null ],
    [ "display", "classPoly1.html#adec2ea612c4bda02487a76742bf1ad5c", null ],
    [ "eval", "classPoly1.html#ad8527086596b6d58cb248db5c16c1bc6", null ],
    [ "k0", "classPoly1.html#a4c8673de8b2bb0d9b550082178126038", null ],
    [ "k1", "classPoly1.html#aa362ae8fc9351d072ca97d9855df0e4a", null ]
];