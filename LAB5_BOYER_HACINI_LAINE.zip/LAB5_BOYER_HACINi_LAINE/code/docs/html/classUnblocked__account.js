var classUnblocked__account =
[
    [ "Unblocked_account", "classUnblocked__account.html#ac39ec9fd9235ecfdd45ce1461c24c895", null ],
    [ "debit", "classUnblocked__account.html#af56458c1d82ff26345d137bf07119b7f", null ]
];