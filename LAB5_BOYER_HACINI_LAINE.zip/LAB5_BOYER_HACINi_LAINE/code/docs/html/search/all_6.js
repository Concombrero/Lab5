var searchData=
[
  ['get_5fid_0',['get_id',['../classClient.html#ae600cde4b0e7c02be20b76fda7f0b7d2',1,'Client']]]
];
