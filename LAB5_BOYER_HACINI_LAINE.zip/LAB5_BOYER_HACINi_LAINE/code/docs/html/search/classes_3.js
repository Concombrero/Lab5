var searchData=
[
  ['poly0_0',['Poly0',['../classPoly0.html',1,'']]],
  ['poly1_1',['Poly1',['../classPoly1.html',1,'']]],
  ['poly2_2',['Poly2',['../classPoly2.html',1,'']]]
];
