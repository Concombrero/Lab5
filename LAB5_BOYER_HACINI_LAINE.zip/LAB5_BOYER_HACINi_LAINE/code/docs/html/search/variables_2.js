var searchData=
[
  ['clients_5fcollection_0',['clients_collection',['../classBank.html#ac6bcfb2d1d3eeb811d885d6e21c478c3',1,'Bank']]]
];
