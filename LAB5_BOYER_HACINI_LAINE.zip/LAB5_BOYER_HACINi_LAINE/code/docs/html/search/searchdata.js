var indexSectionsWithContent =
{
  0: "abcdefgikmnopsu~",
  1: "bcfpsu",
  2: "abcfm",
  3: "abcdefgimopsu~",
  4: "abcikmn",
  5: "o",
  6: "i"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "related",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Friends",
  6: "Macros"
};

