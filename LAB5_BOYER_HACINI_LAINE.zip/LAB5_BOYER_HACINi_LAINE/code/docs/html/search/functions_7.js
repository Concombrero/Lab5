var searchData=
[
  ['insertclient_0',['insertClient',['../classBank.html#a1fd6ab6aba6e9b5378aec019bcb79738',1,'Bank']]]
];
