var searchData=
[
  ['eval_0',['eval',['../classFunction.html#a32e1cd9a5aeca21070e5b5cb535a8094',1,'Function::eval()'],['../classPoly0.html#a99e5280255a4fefcb0c4d16d8be50ecb',1,'Poly0::eval()'],['../classPoly1.html#ad8527086596b6d58cb248db5c16c1bc6',1,'Poly1::eval()'],['../classPoly2.html#afaf70d28e167849d23f956eabf1b0900',1,'Poly2::eval()']]]
];
