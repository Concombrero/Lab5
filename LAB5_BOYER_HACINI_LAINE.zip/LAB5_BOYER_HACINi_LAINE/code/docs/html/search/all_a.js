var searchData=
[
  ['name_0',['name',['../classClient.html#a456e36f9972a8bf3ecdb5f0e70b3bd5d',1,'Client::name'],['../classFunction.html#a161d1ceb4f67f3222caf429fea7b71f1',1,'Function::name']]],
  ['nb_5fcurrentaccounts_1',['nb_currentAccounts',['../classClient.html#acfa1a3e58d0c5599de8c961b5827a9e6',1,'Client']]]
];
