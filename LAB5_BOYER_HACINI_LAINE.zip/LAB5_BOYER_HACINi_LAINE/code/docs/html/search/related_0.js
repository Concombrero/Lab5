var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../classBank.html#aa4f22d51b6c552b2a8b69497c8d3b39d',1,'Bank::operator&lt;&lt;'],['../classClient.html#a84126cd2791173dac14dbac668bd8eee',1,'Client::operator&lt;&lt;']]]
];
