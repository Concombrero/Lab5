var searchData=
[
  ['k0_0',['k0',['../classPoly0.html#ae74022b4f0c2c2e8815df872df3e161b',1,'Poly0::k0'],['../classPoly1.html#a4c8673de8b2bb0d9b550082178126038',1,'Poly1::k0'],['../classPoly2.html#ac9d04ca8ed0a09eaa9b3dedc20a25e68',1,'Poly2::k0']]],
  ['k1_1',['k1',['../classPoly1.html#aa362ae8fc9351d072ca97d9855df0e4a',1,'Poly1::k1'],['../classPoly2.html#adf032de1b0e8fc5dccf73a94f3be49bf',1,'Poly2::k1']]],
  ['k2_2',['k2',['../classPoly2.html#a8f03f5a810d3f53f966eee262d2ff09a',1,'Poly2']]]
];
